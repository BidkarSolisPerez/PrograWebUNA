<?php
    session_start();
    require('PHPFramex.php');
    require('routes.php')
?>
