<?php

  // file: models/UserModel.php
  class UserModel extends Model {
    protected static $table="users";
  }
?>