<?php

class Task extends Model {
}
