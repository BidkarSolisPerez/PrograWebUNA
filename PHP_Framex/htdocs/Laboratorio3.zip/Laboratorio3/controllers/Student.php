<?php
// file: Student.php

class Student extends Model {

  protected static $table = 'student';

}
?>