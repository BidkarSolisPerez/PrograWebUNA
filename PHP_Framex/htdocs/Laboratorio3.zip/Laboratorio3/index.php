<?php
    parse_str(file_get_contents("php://input"), $_REQUEST);
    require('PHPFramex.php');
    require('routes.php')
?>
