<!-- file: views/header.php -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/css/normalize.css">
<link rel="stylesheet" href="/css/skeleton.css">
<link rel="stylesheet" href="/css/skeleton-buttons.css">
<link rel="stylesheet" href="/css/navbar.css">
<script src="/js/navbar.js"></script>